# Missão Marte | Fase 7 — Evolução livre

Este pacote reúne os 21 PNGs do catálogo da Fase 5 e os cinco recursos gráficos preparados para a versão evoluída. As imagens vêm dos pacotes do projeto em suas dimensões originais, com a transparência e os quadros preservados.

## Criador e links de origem

- **Arte-base creditada no projeto.** Skorpio é o autor do kit de peças usado nas adaptações das naves básicas, do astronauta e do engenheiro. As adaptações de Missão Marte incluem montagem, espelhamento, recoloração, efeitos de propulsão e ajuste de escala. [Space Ship Construction Kit — download no OpenGameArt](https://opengameart.org/content/space-ship-construction-kit) · [Perfil do Skorpio](https://opengameart.org/users/skorpio)
- **Licença dos sprites derivados do kit de Skorpio.** O projeto usa CC BY-SA 3.0. Ao redistribuir esses derivados, mantenha o crédito a Skorpio, indique as alterações e preserve a licença. [CC BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/)
- **Editor indicado para a montagem por camadas.** [Photopea](https://www.photopea.com/) · [Guia de camadas](https://www.photopea.com/learn/layers)
- **Outro kit citado durante a preparação.** SpaceShip Building Kit, de BizmasterStudios, foi uma referência de peças. Os créditos da Fase 5 identificam o kit de Skorpio como a origem das peças utilizadas nos sprites que documentam. [SpaceShip Building Kit — OpenGameArt](https://opengameart.org/content/spaceship-building-kit)

Os gráficos personalizados foram desenvolvidos com Lucas Fidelis para o Missão Marte, alguns com assistência de IA. O código `tools/GeradorDeAssets.java` do projeto gera os gráficos provisórios reaproveitados, como os ícones do HUD e os efeitos de impacto e resgate.

## Recursos da Fase 5

Os PNGs abaixo estão em `fase-05/core/assets/imagens/`. O catálogo do cliente inclui também recursos de compatibilidade, como `base.png` e `terreno.png`. Se a Fase 7 partir do cliente da Fase 5, esses arquivos já estão no projeto.

| Grupo | Arquivo | Tamanho do PNG | Quadros |
| --- | --- | --- | --- |
| Naves e propulsão | [nave.png](fase-05/core/assets/imagens/nave.png) | 48 × 48 | 1 |
| Naves e propulsão | [nave_basica.png](fase-05/core/assets/imagens/nave_basica.png) | 48 × 96 | 1 |
| Naves e propulsão | [inimigo.png](fase-05/core/assets/imagens/inimigo.png) | 96 × 48 | 2 |
| Naves e propulsão | [propulsor.png](fase-05/core/assets/imagens/propulsor.png) | 192 × 48 | 4 |
| Naves e propulsão | [propulsor_movimento.png](fase-05/core/assets/imagens/propulsor_movimento.png) | 32 × 16 | 2 |
| Passageiros | [astronauta.png](fase-05/core/assets/imagens/astronauta.png) | 48 × 48 | 1 |
| Passageiros | [engenheiro.png](fase-05/core/assets/imagens/engenheiro.png) | 48 × 48 | 1 |
| Passageiros | [professor.png](fase-05/core/assets/imagens/professor.png) | 48 × 48 | 1 |
| Passageiros | [desconhecido.png](fase-05/core/assets/imagens/desconhecido.png) | 48 × 48 | 1 |
| Cenário | [asteroide.png](fase-05/core/assets/imagens/asteroide.png) | 48 × 48 | 1 |
| Cenário | [base.png](fase-05/core/assets/imagens/base.png) | 192 × 48 | 4 |
| Cenário | [base_pouso_anel.png](fase-05/core/assets/imagens/base_pouso_anel.png) | 128 × 128 | 1 |
| Cenário | [fundo.png](fase-05/core/assets/imagens/fundo.png) | 800 × 600 | 1 |
| Cenário | [fundo_mapa_basico.png](fase-05/core/assets/imagens/fundo_mapa_basico.png) | 798 × 798 | 1 |
| Cenário | [terreno.png](fase-05/core/assets/imagens/terreno.png) | 48 × 48 | 1 |
| Efeitos | [brilho.png](fase-05/core/assets/imagens/brilho.png) | 240 × 48 | 5 |
| Efeitos | [explosao.png](fase-05/core/assets/imagens/explosao.png) | 288 × 48 | 6 |
| Interface | [vaga_livre.png](fase-05/core/assets/imagens/vaga_livre.png) | 24 × 24 | 1 |
| Interface | [vaga_ocupada.png](fase-05/core/assets/imagens/vaga_ocupada.png) | 24 × 24 | 1 |
| Interface | [vida_cheia.png](fase-05/core/assets/imagens/vida_cheia.png) | 24 × 24 | 1 |
| Interface | [vida_vazia.png](fase-05/core/assets/imagens/vida_vazia.png) | 24 × 24 | 1 |

## Recursos da versão evoluída

Copie os cinco PNGs de `fase-07/core/assets/imagens/` para a pasta de imagens do cliente da Fase 7. As viradas de fase, o mapa e a lógica de colisão precisam ser implementados no código que carrega esses recursos.

| Arquivo | Uso | Tamanho do PNG | Quadros |
| --- | --- | --- | --- |
| [nave_evolucao_1.png](fase-07/core/assets/imagens/nave_evolucao_1.png) | Primeira evolução, nave parada | 144 × 144 | 1 de 144 × 144 |
| [nave_evolucao_1_propulsao.png](fase-07/core/assets/imagens/nave_evolucao_1_propulsao.png) | Primeira evolução com animação de propulsão | 432 × 144 | 3 de 144 × 144 |
| [nave_evolucao_2.png](fase-07/core/assets/imagens/nave_evolucao_2.png) | Segunda evolução do jogador | 96 × 144 | 1 de 96 × 144 |
| [inimigo_evoluido.png](fase-07/core/assets/imagens/inimigo_evoluido.png) | Inimigo de asas largas | 96 × 96 | 1 de 96 × 96 |
| [fundo_mapa_evoluido.png](fase-07/core/assets/imagens/fundo_mapa_evoluido.png) | Fundo do mapa da versão evoluída | 1134 × 1134 | 1 de 1134 × 1134 |

- Na folha de propulsão da primeira evolução, leia da esquerda para a direita. O quadro 0 mostra a nave parada. Os quadros 1 e 2 alternam durante o movimento.
- A primeira evolução ocupa cinco casas numa área de 3 × 3, com 1, 3 e 1 casas por fileira, do bico à cauda. A grade serve à lógica de jogo e fica invisível na partida.
- O fundo evoluído é uma imagem de 1134 × 1134 px. O tamanho do tabuleiro em casas deve ser definido na lógica do jogo.
- O cliente da Fase 5 já usa filtragem `Nearest` para manter os contornos dos pixels ao desenhar os sprites.
